#include "MyStack.h"
#include <iostream>

using namespace std;

//Constructor

MyStack::MyStack( )
{
	topOfStack = NULL;
}

//Deep copy constructor

MyStack::MyStack( const MyStack & rhs )
{
	topOfStack = NULL;
	*this = rhs; // deep copy 
}

//Destructor

MyStack::~MyStack( )
{
	makeEmpty( );
}


//Checks if full or not

bool MyStack::isFull( ) const
{
	return false;
}

//Checks if empty or not

bool MyStack::isEmpty( ) const
{
	return topOfStack == NULL;
}

//Return top element of the list

const MazeCoordinate & MyStack::top( ) const
{
	if( !isEmpty( ) )

		return topOfStack->element;
}

//Pop the last element of the stack

void MyStack::pop( ) 
{
	if( !isEmpty( ) )//If stack is not empty, pop the top element
	{
		ListNode *oldTop = topOfStack;
		topOfStack = topOfStack->next;
		delete oldTop;
	}
}

//Push a new element to the top of the stack

void MyStack::push( const MazeCoordinate & x )
{
	topOfStack = new ListNode( x, topOfStack );//Push new element and make it top of the stack
}

//Pop the top item and return the top item

MazeCoordinate MyStack::topAndPop( )
{
	MazeCoordinate topItem = top( );
	pop( );
	return topItem;
}

//Clear whole stack

void MyStack::makeEmpty( )
{
	while( !isEmpty( ) )
		pop( );
}

//To create a deep copy of the current object => overload the equal assignment opperator

const MyStack & MyStack::operator=( const MyStack & rhs )
{
	if( this != &rhs )
	{
		makeEmpty( );
		if( rhs.isEmpty( ) )
			return *this;

		ListNode *rptr = rhs.topOfStack;
		ListNode *ptr  = new ListNode( rptr->element );
		topOfStack = ptr;

		for( rptr = rptr->next; rptr != NULL; rptr = rptr->next )
			ptr = ptr->next = new ListNode( rptr->element );
	}
	return *this;
}


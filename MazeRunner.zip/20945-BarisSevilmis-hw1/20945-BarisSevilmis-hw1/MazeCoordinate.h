#ifndef _MAZECOOR
#define _MAZECOOR

using namespace std;

class MazeCoordinate
{

private:
	
	
	
public:


	int currentX;
	int currentY;

	MazeCoordinate(int xx, int yy);		
	~MazeCoordinate();

	int GetCoorX() const;	
	int GetCoorY() const;
	bool Finished(int size) const;
	
	const MazeCoordinate & operator=(const MazeCoordinate & rhs);


};


#endif
#ifndef _MyStack_
#define _MyStack_

#include <iostream>

using namespace std;

struct MazeCoordinate //This struct is used to store our coordinates, such that we will be able to create stacks of coordiante type
{
	int currentX;
	int currentY;
	MazeCoordinate::MazeCoordinate()
	{}
	MazeCoordinate::MazeCoordinate(int xx, int yy)
		:currentX(xx),currentY(yy)
	{}


};


class MyStack
{

private:

	//To store our stack and bind nodes to each other => Object = Maze Coordinate
	struct ListNode
	{
		MazeCoordinate  element;
		ListNode *next;

		ListNode( const MazeCoordinate & theElement, ListNode * n = NULL )
			: element( theElement ), next( n ) { }
	};

	ListNode *topOfStack;  // list itself is the stack


public:

	MyStack( ); //Constructor
	MyStack( const MyStack & rhs ); //Deep Copy Constructor
	~MyStack( ); //Destructor

	bool isEmpty( ) const; //If empty or not
	bool isFull( ) const; //If full or not
	void makeEmpty( ); //Clear the stack

	void pop( ); //Pop the top element
	void push( const MazeCoordinate & x ); //Push new element to the top
	MazeCoordinate topAndPop( ); //Return top element of the stack and pop it
	const MazeCoordinate & top( ) const; //Return top element of the stack

	const MyStack & operator=( const MyStack & rhs ); //Overloaded equal operator


};

 




#endif
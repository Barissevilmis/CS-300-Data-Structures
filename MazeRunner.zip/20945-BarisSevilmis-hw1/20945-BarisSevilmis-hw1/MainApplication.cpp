#include <iostream>
#include <string>
#include "MyStack.h"

using namespace std;


bool Finished(const MazeCoordinate & myMaze, int sizeX,int sizeY,int sRow,int sCol);//Check if finished
bool InputCheck(string dim);//Check if input is in wanted format
MyStack ListNeigh(const MyStack & myStack, int ** maze, int sizeX,int sizeY) ;//Return list of neighbours
bool CheckNeigh(const MazeCoordinate & solTop, const MazeCoordinate & myStackTop);//Check if given coordinates are neighbours
void OutputSolution(MyStack & myStack);//Output the solution track

int main()
{
	bool finished = false; // To check if main loop has ended
	string sRow, sCol; 
	string sstartRow, sstartCol;
	int row, col, sizeX, sizeY; 
	int startRow, startCol;	
	int ** maze; // Maze Object using double pointer


	//Maze Size 
	cout << "Welcome to the Maze Runner " << endl ;
	cout << "Enter row and column size consecutively: " ;
	cin >> sRow >> sCol ; 

	while(!InputCheck(sRow) || !InputCheck(sCol))// Check if given input is valid 
	{
		cout << "Enter valid coordinates for size, try again: ";
		cin >> sRow >> sCol;
	}

	//If valid => turn size into integer

	row = atoi(sRow.c_str()); 
	col = atoi(sCol.c_str());


	cout << "Enter the starting point: " ;
	cin >> sstartRow >> sstartCol;


	//Start Point
	while(!InputCheck(sstartRow) || !InputCheck(sstartCol) )//Check if starting point is valid
	{
		cout << "Enter valid coordinates for start, try again: "<<endl;
		cin >> sstartRow >> sstartCol;

	}

	//If valid => turn starting point into integer

	startRow = atoi(sstartRow.c_str());
	startCol = atoi(sstartCol.c_str());

	//Display size and entry Point
	cout << row <<" "<< col << endl
		<< startRow <<" "<< startCol<< endl ;

	//Maze Creation

	int matInput;


	maze = new int*[row]; //Maze creation has been initiated
	for(int i = 0; i < row; i++)
	{
		maze[i] = new int[col];

		for(int j = 0; j<col;j++)
		{
			cin >> matInput; // Maze is created also via user input 
			maze[i][j] = matInput;

		}
	}

	cout << endl;

	for(int m = 0; m < row; m++)
	{	
		for(int n = 0; n < col; n++)
			cout<<maze[m][n]<<endl;
		cout<<endl;
	}
		

	//Row and column size do not need to be equal
	sizeX = row;//Row size
	sizeY = col;//Column Size

	MazeCoordinate myMaze (startRow, startCol); //Initial maze object
	int xCoor,yCoor;

	MyStack myStack; //!!! This stack will be our navigator through our maze
	MyStack temp; //!!! This stack will locate neighbour locations and push them into our Main Stack
	MyStack solution; //!!! This stack will contain our winning path

	myStack.push(myMaze); //Push initial coordinate into myStack
	solution.push(myMaze); //Push initial coordinate into myStack


	while(!Finished(myMaze,sizeX,sizeY,startRow,startCol) && finished == false )//Loop until maze is finished
	{
		xCoor = myMaze.currentX; //This contains our current x-coordinate
		yCoor = myMaze.currentY; //This contains our current y-coordinate


		temp = ListNeigh(myStack,maze,sizeX, sizeY); //ListNeigh will return the neighbours of my current location
		myStack.pop();//Since we have our neighbours we can pop the initial value from our navigator stack
		maze[xCoor][yCoor] = 1;//We mark our current location as visited, such that in the next iteration ListNeigh wont push this coordinates into temp

		while(!temp.isEmpty() && finished == false)
		{
			myStack.push(temp.topAndPop());//Push all the neighbour locations into navigator until temp is empty
			//Such that our navigator will have saved all of the neighbours of our current location

			if(Finished(myStack.top(),sizeX, sizeY,startRow,startCol)) //If top coordinate on the temp is on boundary, we can finish
			{
				solution.push(myStack.top());//Push ending point to solution stack
				finished = true; // Set finished to true => 1) Dont push rest of the temp to solution
				//2)Break loop because we are already done
			}

		}
		if(CheckNeigh(solution.top(),myStack.top()))//We check if top of myStack and solution are neighbours

			solution.push(myStack.top());//If they are neighbours,(right path may be found or not) push the coordinate into solution

		else //If they are not neighbours => solution has coordinates of the wrong path
		{
			while(!CheckNeigh(solution.top(),myStack.top())) //Until myStack top coordinate and solution top coordinate are neighbours
				solution.pop();//Pop the wrong coordinates from the solution

			solution.push(myStack.top()); //We have reached our neighbour coordinate in the solution to the top of myStack
			//We can push our top of myStack into solution such that => 1)They are neighbours 2)Continue from new path

		}

		myMaze = myStack.top(); //Current coordinate is changed as the top of myStack in order to continue on our path

	}

	OutputSolution(solution); //Output our solution path

	for(int k = 0; k < row; k++) // Delete maze => no memory leak
	{
		delete [] maze[k];
	}
	delete [] maze;



	cin.get();
	cin.ignore();
	return 0;

}

bool InputCheck(string dim) //This function simply checks if given input is in the wanted format => If integer return true, else return false
{
	for(unsigned int i = 0; i < dim.length() ; i++)
	{
		if(dim[i] < '0' || dim[i] > '9')

			return false;

	}
	return true;

}

MyStack ListNeigh(const MyStack & myStack, int** maze, int sizeX,int sizeY) //Function that returns all the available neighbour coordinates
{																			//To our current coordinate
	MyStack ret;//RStack that will be returned
	int x = myStack.top().currentX;
	int y = myStack.top().currentY;
	MazeCoordinate m(x,y);//Maze coordinate object to store current coordinates


	if(x == 0)//Down boundary
	{
		if(maze[x][y+1] == 0)//Neighbour on boundary => return boundary coordinate and finish
		{	
			m.currentY += 1;
			ret.push(m);
			return ret;
		}
		if(maze[x][y-1] == 0)//Neighbour on boundary => return boundary coordinate and finish
		{	
			m.currentY -= 1;
			ret.push(m);
			return ret;
		}
		if(maze[x+1][y] == 0)//Neighbour below is only available coordinate
		{	
			m.currentX += 1;
			ret.push(m);
			return ret;
		}
	}

	else if(x == sizeX-1 )//Upper boundary
	{
		if(maze[x][y+1] == 0 )//Neighbour on boundary => return boundary coordinate and finish
		{	
			m.currentY += 1;
			ret.push(m);
			return ret;
		}
		if(maze[x][y-1] == 0 )//Neighbour on boundary => return boundary coordinate and finish
		{	
			m.currentY -= 1;
			ret.push(m);
			return ret;
		}
		if(maze[x-1][y] == 0)//Upper neighbour is only available coordinate
		{	
			m.currentX -= 1;
			ret.push(m);
			return ret;
		}
	}
	else if(y == 0)//left boundary
	{
		if(maze[x-1][y] == 0 )//Neighbour on boundary => return boundary coordinate and finish
		{	
			m.currentX -= 1;
			ret.push(m);
			return ret;
		}
		if(maze[x+1][y] == 0 )//Neighbour on boundary => return boundary coordinate and finish
		{	
			m.currentX += 1;
			ret.push(m);
			return ret;
		}
		if(maze[x][y+1] == 0)//Right neighbour is only available coordinate
		{	
			m.currentY += 1;
			ret.push(m);
			return ret;
		}
	}
	else if(y == sizeY -1)//right boundary
	{
		if(maze[x-1][y] == 0 )//Neighbour on boundary => return boundary coordinate and finish
		{	
			m.currentX -= 1;
			ret.push(m);
			return ret;
		}
		if(maze[x+1][y] == 0 )//Neighbour on boundary => return boundary coordinate and finish
		{	
			m.currentX += 1;
			ret.push(m);
			return ret;
		}
		if(maze[x][y-1] == 0)//Left neighbour is only available coordinate
		{	
			m.currentY -= 1;
			ret.push(m);
			return ret;
		}
	}

	else//If coordinates are not on boundary
	{

		if(maze[x-1][y] == 0 )//Below neighbour available
		{	

			m.currentX -= 1;
			ret.push(m);//Push down neighbour into stack
			m.currentX += 1;//Restore current coordinate since it might not be the only neighbour

		}

		if(maze[x+1][y] == 0 )//Upper neighbour available
		{	

			m.currentX += 1;
			ret.push(m);//Push down neighbour into stack
			m.currentX -= 1;//Restore current coordinate since it might not be the only neighbour

		}

		if(maze[x][y-1] == 0 )//Left neighbour available
		{	
			m.currentY -= 1;
			ret.push(m);//Push down neighbour into stack
			m.currentY += 1;//Restore current coordinate since it might not be the only neighbour

		}


		if(maze[x][y+1] == 0 )//Right neighbour available
		{

			m.currentY += 1;
			ret.push(m);//Push down neighbour into stack
			m.currentY -= 1;//Restore current coordinate since it might not be the only neighbour

		}

		return ret; //Return all neigbours taht are pushed into stack
	}


}

bool Finished(const MazeCoordinate & myMaze, int sizeX,int sizeY,int sRow,int sCol) //Checks if win condition is reached
{
	if(myMaze.currentX == sRow && myMaze.currentY == sCol )//If current coordinates are start coordinates => win condition not reached

		return false;

	if(myMaze.currentX == 0 || myMaze.currentY == 0 || myMaze.currentX == sizeX-1 || myMaze.currentY == sizeY -1)
		//If current coordinates are on one of the boundaries => Win condition reached

			return true;

	return false;//Return false if win condition is not reached


}

bool CheckNeigh(const MazeCoordinate & solTop,const MazeCoordinate & myStackTop)//Check if the top of solution and myStack are neighbours
{
	if((solTop.currentX == myStackTop.currentX+1) ||(solTop.currentX == myStackTop.currentX-1))//If X coordinates differ only 1
	{
		if((solTop.currentY == myStackTop.currentY) ||(solTop.currentY == myStackTop.currentY))//And Y coordinates are same

			return true;//Neighbour = true
	}

	else if((solTop.currentY == myStackTop.currentY+1) ||(solTop.currentY == myStackTop.currentY-1))//If Y coordinates differ only 1
	{
		if((solTop.currentX == myStackTop.currentX) ||(solTop.currentX == myStackTop.currentX))//And X coordinates are same

			return true;// Neighbour = true
	}
	return false;
}

void OutputSolution(MyStack & myStack)//Output our solution path
{
	MyStack printStack;//Second stack to reverse our path => Otherwise output will be in reverse

	cout << "The solution to the puzzle is:" << endl;

	while(!myStack.isEmpty())//Until myStack is empty push every element into print Stack
	{
		printStack.push(myStack.topAndPop());
	}
	while(!printStack.isEmpty())//Pop every element of print stack, which are in the order of wanted output format
	{
		cout << printStack.top().currentX << " " << printStack.top().currentY << endl;
		myStack.push(printStack.topAndPop());
	}

}
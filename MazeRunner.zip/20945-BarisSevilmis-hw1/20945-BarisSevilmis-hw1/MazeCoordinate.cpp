#include "MazeCoordinate.h"

using namespace std;

MazeCoordinate::MazeCoordinate(int xx, int yy)
{
	currentX = xx;
	currentY = yy;	

}


int MazeCoordinate::GetCoorX() const
{
	return currentX;
}
int MazeCoordinate::GetCoorY() const
{
	return currentY;
}


const MazeCoordinate & MazeCoordinate::operator=(const MazeCoordinate & rhs)
{
	if( this != &rhs )
	{
		currentX = rhs.currentX;
		currentY = rhs.currentY;
	}
	return *this;
}




bool MazeCoordinate::Finished(int size) const
{
	if(currentX == 0 || currentY == 0 || currentX == size-1 || currentY == size -1)

		return true;


}



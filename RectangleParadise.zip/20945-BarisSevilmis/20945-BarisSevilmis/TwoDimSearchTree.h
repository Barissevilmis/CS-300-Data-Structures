#ifndef _TwoDimTree
#define _TwoDimTree

#include "Rectangle.h"
#include "LinkedList.h"
#include <vector>

using namespace std;

struct Query//Struct that will contain query points => Contains x and y
{
	int x;
	int y;

	Query::Query()
	{}

	Query::Query(int xx,int yy)
		:x(xx),y(yy)
	{}

};


class TwoDimTreeNode 
{
public:

	TwoDimTreeNode();//Default constructor of tree node
	
	TwoDimTreeNode(const Rectangle & ex,List ver,List hor, TwoDimTreeNode *topL, TwoDimTreeNode *topR, TwoDimTreeNode *botL, TwoDimTreeNode *botR)
		:Extent(ex),Vertical(ver),Horizontal(hor),TopLeft(topL),TopRight(topR),BottomLeft(botL),BottomRight(botR)
	{}//Constructor that we will mostly use

private:

	Rectangle Extent;//Boundaries of tree node
	List Vertical, Horizontal;//Linked lists to store our rectangles
	TwoDimTreeNode *TopLeft, *TopRight,//Child nodes of our current node
		*BottomLeft, *BottomRight;

	friend class TwoDimSearchTree;//Search Tree is friend with our tree node class
};

class TwoDimSearchTree
{

public:

	TwoDimSearchTree(const Rectangle & Extent);//Tree constructor will be created with the given boundaries
	~TwoDimSearchTree();//Destructor of Search tree

	void Add(const Rectangle & ex);//Insert rectangles into tree=>Public method
	vector<Rectangle> Find(const Query & find);//Search for intersections of query points with rectangles=>Public
	void MakeEmpty(TwoDimTreeNode * t);//Clear the tree

private:

	vector<Rectangle> Find(const Query & find,TwoDimTreeNode* r);//Private=>Public will call this to add with root node of tree since root == private
	void Add(const Rectangle & ex,TwoDimTreeNode* &r);//Private=>Public will call this to find with root node of tree since root == private
	TwoDimTreeNode * root;//Root node of tree

};



#endif
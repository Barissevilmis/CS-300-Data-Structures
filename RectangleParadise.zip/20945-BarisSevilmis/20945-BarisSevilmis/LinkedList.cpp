#include "LinkedList.h"

using namespace std;

List::List( )
{
	header = new ListNode();

}

List::List( const List & rhs )
{
	header = new ListNode();
	*this = rhs;  // Deep Copy
}

List::~List( )
{
	makeEmpty( );  // Get rid of all list nodes
	delete header;  // then get rid of the header
}



bool List::isEmpty( ) const
{  // see if the header  point to NULL 

	return header -> next == NULL;
}

//Insert object at the end of the given list
void List::insert( const Rectangle & x )
{
	ListNode * temp = header;

	while(temp->next != NULL)

		temp = temp->next;

	temp->next = new ListNode(x, NULL);
}

//Return current node of the wanted element
ListNode* List::find(const Rectangle & x ) const
{
	ListNode *itr = header->next;

	while( itr != NULL && itr -> element != x )
		itr = itr->next;

	return itr;
}

//Return previous node of wanted element
ListNode* List::findPrevious( const Rectangle & x ) const
{
	ListNode*itr = header;

	while( itr->next != NULL && itr->next->element != x )

		itr = itr->next;

	return itr ;
}

//Remove certain element from the list
void List::remove( const Rectangle & x )
{
	ListNode *p =  findPrevious( x );

	if( p->next != NULL )
	{
		ListNode *oldNode = p->next;
		p->next = p->next->next;  // Bypass deleted node
		delete oldNode;
	}
}

//Return first element
ListNode* List::zeroth( ) const
{
	return header;
}

//Return second element
ListNode* List::first( ) const
{
	return header->next;
}

//Empty the whole list
void List::makeEmpty( )
{
	while(!isEmpty())
	{
		ListNode * temp;
		temp = first();
		header -> next = temp -> next;
		delete temp;
	}

}
//Overloaded asssignment operator if both sides are not equal
const List & List::operator=( const List & rhs )
{
	if( this != &rhs )
	{
		makeEmpty( );

		ListNode *itr = rhs.zeroth();
		while(itr-> next !=NULL)
		{
			insert(itr->element);
			itr = itr -> next;
		}
	}
	return *this;
}

#ifndef _Rectangle
#define _Rectangle

using namespace std;

class Rectangle
{
// Bottom > Top and Right > Left
//R.Left <= x < R.Right and R.Top <= y < R.Bottom
public:


	Rectangle();//Default rectangle constructor
	Rectangle(int top, int left, int bottom, int right)//Constructor with initialized boundaries
		:Top(top),Left(left),Bottom(bottom),Right(right)
	{}

	
	//Return boundary values of rectangle
	int GetTop() const;
	int GetBot() const;
	int GetRight() const;
	int GetLeft() const;

	const Rectangle & operator=(const Rectangle & rhs );//Overloaded assignment operator
	const bool & operator!=(const Rectangle & rhs );//Overloaded notEqual operator


private:
	int Top; // y coordinate of the upper edge
	int Left; // x coordinate of the left edge
	int Bottom; // y coordinate of the bottom edge
	int Right; // x coordinate of the right edge


};


#endif
#include <iostream>
#include <fstream>
#include <string>
#include "TwoDimSearchTree.h"
#include "Rectangle.h"
#include <sstream>

using namespace std;



int main()
{
	ifstream ifile;
	string fileName = "rectdb.txt"; //File that will be giving our rectangles and extent
	string firstLine,line;
	int top,left,bottom,right;

	ifile.open(fileName.c_str());//We need to open the student list first, so try it until it opens correctly below


	//Create Search Tree
	getline(ifile,firstLine);//First Line of file => Extent => Limits of root node of tree

	stringstream firstInput(firstLine);

	firstInput>>top>>left>>bottom>>right;//Read values of Extent

	if(top < 0)//If top value is less then 0 => Extent not given correctly
	{
		cout<<"Extent not given correctly, terminating...";
		return 0;
	}
	else
	{
		Rectangle Extent(top,left,bottom,right);//Create Extent with given variables

		TwoDimSearchTree quadTree(Extent);//Create quad tree 

		//Tree created with the given extent


		//Insert all rectangles
		while(getline(ifile,line))//Read file line by line, starting from the second line
		{
			stringstream input(line);

			input>>top>>left>>bottom>>right; //Starting from second line => Rectangles to be inserted in tree

			if(top == -1)//If top value is -1 our input from file is finished

				break;//Break loop

			else
			{
				Rectangle insertRec(top,left,bottom,right);//Create rectangle

				quadTree.Add(insertRec);//Insert rectangle to the tree
			}

		}
		int x,y;
		vector<Query> vec;//Our query points are stored in an array(vector)
		vector<Rectangle> result;//Query point may be on multiple rectangles store all intersecting rectangles in an array

		while(true)//Loop until x value is given as 1
		{
			cin >> x >> y;//Enter x and y values (query points)

			if(x == -1)//If x  is -1 break from the loop
				break;

			else
			{
				Query search(x,y);//Create query point
				vec.push_back(search);//Push query point into vector
			}
		}

		cout<<endl;

		for(int i = 0; i < vec.size();i++)//Search all query points => Iterate until query vector is finished
		{
			cout << vec[i].x <<" "<< vec[i].y <<endl;//Display query points
			result = quadTree.Find(vec[i]);//Start seearching for intersecting rectangles in tree
			cout<<result.size()<<endl;//Display how many intersections exist
			
			for(int j=0; j<result.size();j++)//Display every intersecting rectangle
			{
				cout<<result[j].GetTop()<<" "<<result[j].GetLeft()<<" "<<result[j].GetBot()<<" "//Boundaries of intersecting rectangle
					<<result[j].GetRight()<<endl;//Which intersecting rectangle
			}
			
		}
	}


	cin.get();
	cin.ignore();
	return 0;
}
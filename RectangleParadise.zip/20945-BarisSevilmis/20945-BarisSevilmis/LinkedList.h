#ifndef _LinkedList
#define _LinkedList


#include "Rectangle.h"
#include <iostream>

using namespace std;


//ListNode class to store List nodes 
class ListNode
{
	ListNode( const Rectangle & theElement = Rectangle( ), ListNode * n = NULL )
		: element( theElement ), next( n ) { }  // Constructor 

	Rectangle   element;
	ListNode *next;

	friend class List;
	friend class ListItr;

};
//Iterator class to iterate over given linked list
class ListItr
{
public:
	ListItr( ) 
		:current( NULL ) 
	{ }

	ListItr( ListNode *theNode )//Give the Node as starting point
		: current( theNode ) 
	{ }

	bool isPastEnd( ) const//Is end point reached
	{ 
		return current == NULL; 
	}
	void advance( )//Advance one node
	{ 
		if( !isPastEnd( ) ) 
			current = current->next; 
	}
	const Rectangle & retrieve( ) const//Retrieve current value if not NULL
	{ 
		if( !isPastEnd( ) ) 
			return current->element; 
	}

private:
	ListNode *current;    // Current position

	friend class List; // Grant access to constructor
};


class List
{
public:
	List( );//Constructor
	List( const List & rhs );//Deep copy constructor
	~List( );//Destructor


	bool isEmpty( ) const;//Check if empty
	void makeEmpty( );//Empty the list

	ListNode* zeroth( ) const;//Return first element
	ListNode* first( ) const;//Return second element
	void insert( const Rectangle & x);//Insert Rectangle object into list
	ListNode* find( const Rectangle & x ) const;//Find searched node from list
	ListNode* findPrevious( const Rectangle & x ) const;//Find previous node of the searched node
	void remove( const Rectangle & x );//Remove certain element list

	const List & operator=( const List & rhs );//Overload assignment operator



private:
	ListNode *header;
};


#endif
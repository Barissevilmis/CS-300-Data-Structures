#include "TwoDimSearchTree.h"

using namespace std;

TwoDimSearchTree::TwoDimSearchTree(const Rectangle & Ex)
{
	List h,v;//Create empty lists=> h for horizontal and v for vertival

	root = new TwoDimTreeNode(Ex,h,v,NULL,NULL,NULL,NULL);//Create root node=>NULL values for childs 
}

TwoDimSearchTree::~TwoDimSearchTree()
{
	MakeEmpty(root);//MakeEmpty handles all dynamic memory deletion
}

void TwoDimSearchTree::MakeEmpty(TwoDimTreeNode * t)
{
	if( t != NULL )//If current NULL is not NULL
	{
		//Call every child of current node recursively
		MakeEmpty( t->BottomLeft);
		MakeEmpty( t->BottomRight );
		MakeEmpty( t->TopLeft);
		MakeEmpty( t->TopRight );
		delete t;//Delete current node
	}
	t = NULL;//After deleting equate current pointer to NULL

}

//Public Add Method
void TwoDimSearchTree::Add(const Rectangle & ex)
{
	Add(ex,root);//Call private Add method by also sending the root node 
}

//Private Add Method
void TwoDimSearchTree::Add(const Rectangle & ex, TwoDimTreeNode* &r)
{
	int verLine = (r -> Extent.GetLeft() + r -> Extent.GetRight())/2 ;//Vertical List of current node
	int horLine = (r-> Extent.GetTop() + r -> Extent.GetBot())/2;//Horiontal List of current node


	if(ex.GetRight() >= verLine && ex.GetLeft() <= verLine)//If given rectangle is on the vertical list 
	{
		if(r->Vertical.find(ex) == NULL)//If given rectangle does not exist in the vertical list
		{
			r->Vertical.insert(ex);//Insert into vertical list of current node
		}
	}
	else if(ex.GetBot() >= horLine && ex.GetTop() <= horLine)//If given rectangle is on the horizontal list 
	{
		if(r->Horizontal.find(ex) == NULL)//If given rectangle does not exist on the horizontal list
		{
			r->Horizontal.insert(ex);//Insert into horizontal list of current node
		}
	}
	else//If rectangle is not on both of the lists => Then create necessary child nodes recursively
	{
		List h,v;//Create empty lists for the creation of child nodes
		if(verLine < ex.GetLeft() && horLine > ex.GetBot())//If rectangle is on top right quadrant
		{
			if(r->TopRight == NULL)//If TopRight child is not created
			{
				Rectangle rec(r->Extent.GetTop(),verLine+1,horLine+1,r->Extent.GetRight());//Create boundaries of TopRight child

				r->TopRight = new TwoDimTreeNode(rec,h,v,NULL,NULL,NULL,NULL);//Create TopRight Node with given empty lists and boundaries
			}
			Add(ex,r->TopRight);//Now we are sure TopRight child exists so proceed now=>Recursion
		}
		else if(verLine > ex.GetRight() && horLine > ex.GetBot())//If rectangle is on top left quadrant
		{
			if(r->TopLeft == NULL)//Create boundaries of TopLeft child
			{
				Rectangle rec(r->Extent.GetTop(),r->Extent.GetLeft(),horLine,verLine);//Now we are sure TopLeft child exists so proceed now

				r->TopLeft = new TwoDimTreeNode(rec,h,v,NULL,NULL,NULL,NULL);//Create TopRight Node with given empty lists and boundaries
			}

			Add(ex,r->TopLeft);//Now we are sure TopLeft child exists so proceed now=> Recursion
		}

		//Same process for bottom right
		else if(verLine < ex.GetLeft() && horLine < ex.GetTop())
		{
			if(r->BottomRight == NULL)
			{
				Rectangle rec(horLine+1,verLine+1,r->Extent.GetBot(),r->Extent.GetRight());

				r->BottomRight = new TwoDimTreeNode(rec,h,v,NULL,NULL,NULL,NULL);
			}
			Add(ex,r->BottomRight);
		}

		//Same process for bottom left
		else if(verLine > ex.GetRight() && horLine < ex.GetTop())
		{
			if(r->BottomLeft == NULL)
			{
				Rectangle rec(horLine,r->Extent.GetLeft(),r->Extent.GetBot(),verLine);

				r->BottomLeft = new TwoDimTreeNode(rec,h,v,NULL,NULL,NULL,NULL);
			}
			Add(ex,r->BottomLeft);
		}

	}

}

//Public Find method => Return vector of intersecting rectangles
vector<Rectangle> TwoDimSearchTree::Find(const Query & point)
{
	vector<Rectangle> result;
	result = Find(point, root);//Call private Find method 
	return result;
}

//Private find method
vector<Rectangle> TwoDimSearchTree::Find(const Query & point, TwoDimTreeNode* r)
{
	vector<Rectangle> result,recResult;//result = intersecting rectangles from current node 
	//recResult = intersecting rectangles from child nodes

	if(r != NULL)//If current node is not NULL
	{
		int verLine = (r -> Extent.GetLeft() + r -> Extent.GetRight())/2 ;//Vertical List of current node
		int horLine = (r-> Extent.GetTop() + r -> Extent.GetBot())/2;//Horizontal List of current node

		ListItr vitr(r->Vertical.zeroth());//Iterator in order to check all elements of vertical list =>Start from the header
		ListItr hitr(r->Horizontal.zeroth());//Iterator in order to check all elements of horizontal list =>Start from the header

		while(!(vitr.isPastEnd()))//If vertical iterator is not on NULL
		{
			//Get all boundaries of current rectangle
			int t = vitr.retrieve().GetTop();
			int b = vitr.retrieve().GetBot();
			int rr = vitr.retrieve().GetRight();
			int l = vitr.retrieve().GetLeft();

			if((t <= point.y && point.y < b) && (l <= point.x && point.x< rr))//If given point is between the boundaries

				result.push_back(vitr.retrieve());//Push rectangle into result vector


			vitr.advance();//Iterate one forward

		}

		while(!hitr.isPastEnd())//If horizontal iterator is not on NULL
		{
			//Get all boundaries of current rectangle
			int t = hitr.retrieve().GetTop();
			int b = hitr.retrieve().GetBot();
			int rr =hitr.retrieve().GetRight();
			int l = hitr.retrieve().GetLeft();

			if((t <= point.y && point.y< b) && (l <= point.x && point.x < rr))//If query point is between the boundaries

				result.push_back(hitr.retrieve());//Push into result vector

			hitr.advance();//Advance once

		}

		//Recursively search all child nodes if query point is in their quadrant=>recResult stores their results
		if(point.x <= verLine && point.y <= horLine )
			recResult = Find(point,r->TopLeft);

		if(point.x >= verLine && point.y <= horLine)
			recResult =Find(point,r->TopRight);

		if(point.x <= verLine && point.y >= horLine)
			recResult =Find(point,r->BottomLeft);

		if(point.x >= verLine && point.y >= horLine)
			recResult = Find(point,r->BottomRight);

	}
	//Copy every element of recResult into main result and return main result vector
	for(unsigned int j = 0; j < recResult .size();j++)
	{
		result.push_back(recResult[j]);
	}

	return result;
}
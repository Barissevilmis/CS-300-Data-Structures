#include "Rectangle.h"

using namespace std;

//Constructor
Rectangle::Rectangle()
{
	Top = 0;
	Bottom = 0;
	Left = 0;
	Right = 0;
}

//Return Top
int Rectangle::GetTop() const
{
	return Top;
}

//Return Bottom
int Rectangle::GetBot() const
{
	return Bottom;
}

//Return Left
int Rectangle::GetLeft() const
{
	return Left;
}

//Return Right
int Rectangle::GetRight() const
{
	return Right;
}


const Rectangle & Rectangle::operator=(const Rectangle & rhs)
{
	//Copy boundary values of right side to current Rectangle
	if( this != &rhs )//If both sides are not equal
	{
		Top = rhs.Top;
		Bottom = rhs.Bottom;
		Left = rhs.Left;
		Right = rhs.Right;		
	}

	return *this;
}

//Check if current Rectangle is equal to the rhs Rectangle => Check all boundaries
const bool & Rectangle::operator!=(const Rectangle & rhs)
{
	if(Top == rhs.Top && Bottom == rhs.Bottom && Left == rhs.Left && Right == rhs.Right)
		return false;

	return true;
}




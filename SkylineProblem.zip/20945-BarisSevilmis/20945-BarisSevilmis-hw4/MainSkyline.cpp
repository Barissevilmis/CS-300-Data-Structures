#include "ModifiedHeap.h"
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;

void ResultOutput(vector<int> result);
void percDown( vector<Building> &a, int i, int n );
void HeapSort(vector<Building> & a);
bool Exists(const vector<int> & result, int x);
int GetGreater(const vector<int> & result,int x, int y);
int GetLess(const vector<int> & result,int x, int y);

int main()
{

	ifstream ifile;
	string fileName = "input.txt";
	string line,firstLine;

	ifile.open(fileName.c_str());//Open file
	/*First Line = > Building amount
	*Preceeding = > X-Left->Y-Top->X->Rigth*/
	int size;
	int xLeft,yTop,xRight;
	int prevMax,currMax;

	getline(ifile,firstLine);//First Line of file => size

	stringstream firstInput(firstLine);

	firstInput>>size;//Get size

	vector<Building> vec(2*size);//Vector to keep start points and end point of our vector
	vector<int> result;

	int i = 0;
	int	j = 1;
	while(getline(ifile,line))//Read buildings line by line
	{
		stringstream input(line);

		input>>xLeft>>yTop>>xRight;

		//True means start of building and false means end of building
		//Both start and end must have same labels since they are the same building
		vec[i] = Building(xLeft,yTop,true,j+1);
		vec[i+1] = Building(xRight,yTop,false,j+1);
		i+=2;
		j++;

	}

	HeapSort(vec);//Sort vector=> Edge case 1 is done in sort since if an end point and a start point have same x coordinate, start point is below end 


	ModifiedHeap<int> heapster(2*size);//Modified heap object created

	//Height as first parameter and label as second parameter, number of times we saw this height

	heapster.insert(0,1);//Insert 0 as height just in case with first label
	result.push_back(0);//Push 0,0 in the result vector, if we have a building with height more than 0 it will be replaced
	result.push_back(0);

	prevMax = 0;
	int removeVal;
	bool isStart = true;

	for(unsigned int i = 0; i < vec.size();i++)
	{
		if(vec[i].start)//If start point , insert into modified heap
		{

			heapster.insert(vec[i].y,vec[i].label);
			isStart = true;

		}

		else if(!vec[i].start)//If end point remove from heap, since start point exists with same label
		{
			removeVal = heapster.remove(vec[i].label);
			isStart = false;
		}

		currMax = heapster.GetMax();//Get current max value in heap


		if(currMax != prevMax && isStart)//If current maximum is not equal with the previous one and it is a start point
		{
			if(!Exists(result,vec[i].x))//If same x coordinate is not pushed into vector before, push x coordinate and height
			{
				result.push_back(vec[i].x);
				result.push_back(vec[i].y);
			}
			else//If same x coordinate already exists, get put maximum height for that x coordinate => edge case 2
			{
				int swapVal = GetGreater(result,vec[i].x,vec[i].y);
				result.pop_back();
				result.push_back(swapVal);
			}
		}
		if(currMax != prevMax && !isStart)//If end point and current max is not equal to previous height
		{
			
			if(!Exists(result,vec[i].x))//If same x coordinate does not exist => push removed buildings height with max height in heap
			{
				result.push_back(vec[i].x);
				result.push_back(currMax);
			}
			else if(Exists(result,vec[i].x))//If same x coordinate exists, get put minimum value for that x coordinate if both are end => edge case 3
			{
				int swapVal = GetLess(result,vec[i].x,currMax);
				result.pop_back();
				result.push_back(swapVal);
			}

		}

		prevMax = currMax;//Now previous max is equal to current max
	}

	ResultOutput(result);//Output


	cin.get();
	cin.ignore();
	return 0;
}

bool Exists(const vector<int> & result, int x)//Checks if given x point exists in output vector or not
{
	for(unsigned int i = 0; i< result.size(); i+=2)
	{
		if(result[i] == x)
			return true;
	}

	return false;
}
int GetLess(const vector<int> & result,int x, int y)//Returns the minimum value for height if two x points are same
{
	for(unsigned int i = 0; i< result.size(); i+=2)
	{
		if(result[i] == x)
		{
			if(result[i+1] > y)
				return y;
			else 
				return result[i+1];
		}
	}
}
int GetGreater(const vector<int> & result,int x , int y)//Returns maximum value for height if two x points are same
{
	for(unsigned int i = 0; i< result.size(); i+=2)
	{
		if(result[i] == x)
		{
			if(result[i+1] < y)
				return y;
			else 
				return result[i+1];
		}
	}
}

void percDown( vector<Building> &a, int i, int n )//Percolate down
{
	int child;
	Building tmp;

	//Since vector starts from zero our first child will be 2i+1 and second will be 2i+2
	for(tmp=a[i] ; (2*i+1) < n; i = child )
	{
		child = 2*i+1;
		if( child != n-1 && a[child ] < a[child+1] )//Get the max child
			child++;
		if(tmp < a[child])
			a[i] = a[ child ];
		else
			break;
	} 
	a[i] = tmp;
}

void HeapSort(vector<Building> & a)//At the end of this function, our coordinates will be in ascending order, considering also the edge cases
{
	// buildHeap
	for(int i = a.size()/2; i >=0; i --)
		percDown(a,i, a.size());
	// sort
	for(int j = a.size()- 1; j >0; j --)
	{
		Building temp = a[j];
		a[j] = a[0];
		a[0] = temp;// swap max to the last pos.
		percDown(a,0,j); // re-form the heap
	}
}

void ResultOutput(vector<int> result)//Output the result
{
	for(unsigned int k = 0; k < result.size(); k+=2)
	{
		cout<<result[k]<<" "<<result[k+1]<<endl;
	}
}
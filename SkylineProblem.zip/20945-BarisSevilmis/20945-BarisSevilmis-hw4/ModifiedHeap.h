#ifndef _HEAP_
#define _HEAP_

#include <iostream>
#include <vector>
#include <string>

using namespace std;


class Building//Class that will keep our x,y,label and whether its a start or end point
{
public:
	int x;
	int y;
	bool start;
	int label;


	Building::Building()
	{}

	Building::Building(int xx, int yy, bool s,int l)
		:x(xx),y(yy),start(s),label(l)
	{}

	bool operator<(const Building & rhs)//Operator < overloaded for heapsort, very important. All edge cases considered
	{
		if(x < rhs.x)
			return true;

		else if(x > rhs. x)
			return false;

		else if(x == rhs.x)
		{
			if(start && !(rhs.start))
			{
				if(y <= rhs.y)
					return true;
				else
					return false;

			}
			else if(!start && rhs.start)
				return false;

			else if(start && rhs.start)
			{
				if(y <= rhs.y)
					return true;

				else
					return false;
			}
			else if(!start && !(rhs.start))
			{

				if(y <= rhs.y)
					return false;

				else
					return true;
			}		
		}
	}
};


//Modified Heap Class
template<class Comparable>
class ModifiedHeap
{

public:
	ModifiedHeap(int size);//Constructor with size parameter
	~ModifiedHeap();

	void insert(Comparable value,int label);//Insert start point
	Comparable remove(int label);//Remove end point
	Comparable GetMax();//Return value stored at 1 since it is a max heap

	bool isEmpty();//Check if empty or not

private:


	struct MarkUp//Our main array data type which will store height and corresponding label
	{
		Comparable height;
		int marker;
	};

	vector<MarkUp> compVec;//Heap vector
	vector<int> labelVec;//Label vector additional to heap vector
	int currentSize;


	void percolateDown( int hole );//Percolate down 

};

template<class Comparable>
ModifiedHeap<Comparable>::ModifiedHeap(int size)//Adjust sizes of our private data members
{
	compVec.resize(size+1);
	labelVec.resize(size+1);
	currentSize = 0;

	for(int i = 0; i < size+1; i++)
	{
		compVec[i].marker = -1;
		labelVec[i]= -1;
	}
}

template<class Comparable>
ModifiedHeap<Comparable>::~ModifiedHeap()
{
	for(int i = 0; i< compVec.size();i++)
		compVec.pop_back();
	for(int i = 0; i< labelVec.size();i++)
		labelVec.pop_back();
}

template<class Comparable>
bool ModifiedHeap<Comparable>::isEmpty() //If first index is non existing, is empty
{
	if(currentSize < 1)
		return true;

	return false;
}

template<class Comparable>
Comparable ModifiedHeap<Comparable>::GetMax() //Return max value
{
	return compVec[1].height;
}

template <class Comparable>//Percolate down given hole
void ModifiedHeap<Comparable>::percolateDown( int hole )
{
	int child;
	Comparable temp = compVec[hole].height; 
	int tempLbl = compVec[hole].marker;

	while(hole * 2 <= currentSize)
	{   
		child = (hole* 2);
		if( child != currentSize && compVec[child + 1].height > compVec[child].height )//Get max child
			child++;

		if( compVec[child].height > temp)//If our value is less than maximum child, precolate down
		{
			//Adjust height and labels as said in pdf documen, marker and labelVec corresponding index must have same index
			compVec[hole].height = compVec[child].height;
			compVec[hole].marker = compVec[child].marker;//This and the line below is actually are same
			labelVec[compVec[hole].marker] = hole;//Same with upper line
		}
		else
			break;

		hole = child;
	}
	compVec[hole].height = temp;//Put temp into required spot
	compVec[hole].marker = tempLbl;
}

template <class Comparable>
void ModifiedHeap<Comparable>::insert(Comparable obj,int label)
{

	// Percolate up
	// Note that instead of swapping we move the hole up
	int hole = ++currentSize;
	while((hole > 1 )&& ((obj >= compVec[hole / 2].height )))
	{
		compVec[hole].height = compVec[hole / 2].height;//Height exchange with greater child
		compVec[hole].marker = compVec[hole / 2].marker;//Label exchange with greater child
		labelVec[compVec[hole].marker] = hole ;//Update label vector 
		hole /= 2;
	}

	compVec[hole].height = obj;//Put new element into hole, with corresponding label and update label vector
	compVec[hole].marker = label;
	labelVec[compVec[hole].marker] = hole;


}
template<class Comparable>//Remove given labels corresponding height from heap
Comparable ModifiedHeap<Comparable>::remove(int label)
{
	if(!isEmpty())//If not empty, change given label element with last element, and decrease current size by 1
	{//Send replaced element to percolate down function and return the removed item

		Comparable item = compVec[labelVec[label]].height;

		compVec[labelVec[label]].marker = compVec[currentSize].marker;
		compVec[labelVec[label]].height = compVec[currentSize--].height;
		labelVec[compVec[labelVec[label]].marker] = labelVec[label];

		percolateDown(labelVec[label]);

		return item;
	}

}




#endif
#ifndef _HASHMAP
#define _HASHMAP


#include <iostream>
#include <string>

using namespace std;

#define SIZE 4096//Given size of hash array

enum EntryType{EMPTY,ACTIVE};//Given entries must be either marked as empty or active

template<class HashedObj>
class HashMap
{
public:

	explicit HashMap(const HashedObj & notFound);//Constructor

	void insert(const HashedObj & obj );//Insert given template(string) key to a given index
	const HashedObj & findKey(const int & cod) const;//Return string key part of the given string-code pair

	int hashing(const int & key) const;//Hash in terms of code part of given string-code pair

	const bool & operator==(const HashedObj & rhs) const;//Overloaded equality check operators
	const bool & operator!=(const HashedObj & rhs) const;

private:
	struct HashEntry//Struct for hash entries
	{
		HashedObj key;//Template(string type) key
		int code;//Code equivalent 
		EntryType type;//Empty of active

		HashEntry(EntryType t = EMPTY)//Mark as empty when created
			:type(t)
		{}

		HashEntry(HashedObj k,int c, EntryType t = EMPTY)
			:key(k),code(c),type(t)
		{}

	};
	HashEntry hashArray[SIZE];//Create static array with given size
	int currentPos;//Keep current position
	const HashedObj ITEM_NOT_FOUND;//If some search fails to find string part of given value => Return this


	HashedObj findStr(const int & x) const;//Find position of given string type object
	bool isActive(int curr) const;//Check if given index is active or empty

};

template<class HashedObj>//Template constructor
HashMap<HashedObj>::HashMap(const HashedObj & notFound)
	:ITEM_NOT_FOUND(notFound)

{
	for(int i = 0; i < 256; i++)//Enter 0-255=> All ASCII characters are entered into hashmap
	{
		string s;
		s = (char) i;
		int hashIndex = hashing(i);//Hash in terms of integer values
		hashArray[hashIndex]= HashEntry(s,i,ACTIVE);//Put all string-code pairs into hashmap
	}
	currentPos = 256;//Current Position is 256-> since we will continue inserting from 256
}
template <class HashedObj>
bool HashMap<HashedObj>::isActive(int curr) const//Checks if given index is active or not
{
	return hashArray[curr].type == ACTIVE;
}

template<class HashedObj>
int HashMap<HashedObj>::hashing(const int & key) const//Hash function
{
	return  (key % SIZE);//Return hashed index

}

template<class HashedObj>
void HashMap<HashedObj>::insert(const HashedObj & obj )//Insert given template(string) object
{
	int curr = hashing(currentPos);//Hash current available code such as we did in constructor
	if(isActive(curr))
		return;
	hashArray[curr] = HashEntry(obj,currentPos, ACTIVE );//Enter template(string)-code pair into hashed index
	currentPos++;//Increment current position, for upcoming string objects
}

template<class HashedObj>
const HashedObj & HashMap<HashedObj>::findKey(const int & obj ) const//Find key from given code pair
{
	HashedObj curr = findStr(obj);//Find object
	if(curr != "")//If returned value is not empty
		return hashArray[obj].key; //return key from hashed index

	return ITEM_NOT_FOUND;//If template(string) does not exist return "0"
}

template<class HashedObj>
HashedObj HashMap<HashedObj>::findStr( const int & obj ) const//Find string from given code
{
	int curr= hashing(obj);//Hash given index in order to reach its true position 

	while( hashArray[curr].type != EMPTY && hashArray[curr].code != obj )//If returned index is active but does not contain our key
	{
		curr++ ;  //Linear probing
		if(curr >= SIZE)             //If we reach a size greater or equal from our hasharray size
			curr = curr-SIZE;        //Do necessary operation        
	}

	return hashArray[curr].key;//Return key

}

template<class HashedObj>
const bool & HashMap<HashedObj>::operator==(const HashedObj & rhs) const//Overloaded equality check operator
{
	int curr = hashing(rhs);
	if(hashArray[curr].key == rhs)
		return true;

	return false;
}
template<class HashedObj>
const bool & HashMap<HashedObj>::operator!=(const HashedObj & rhs) const//Overloaded inequality check operator
{
	int curr = hashing(rhs);
	if(hashArray[curr].key == rhs)
		return false;

	return true;
}
#endif

#include "HashMap.h"
#include <fstream>
#include <sstream>


using namespace std;


int main()
{
	char ch;
	HashMap<string> map("--_NOTFOUND@@NOTFOUND_--");//Since 0 won't be used let us use it as ITEM_NOT_FOUND
	int prevElement, newElement;

	string fileName = "compout";//Input and output files
	string fileName2 = "decompout";
	ifstream input;
	ofstream output;

	input.open(fileName.c_str());//Open both files
	output.open(fileName2.c_str());

	string str,str1;//Str to keep previous element, str1 to keep new element
	

	
	input >> prevElement;//Read first int code value
	str = map.findKey(prevElement);//Find index of given code
	output<< str;//Output its string key equivalent

	while(!input.eof()) //Until end of file
	{
		while(input >> newElement)//Read all elements
		{
			str1 = map.findKey(newElement);//Find string equivalent of new element ==> text(x)
			str = map.findKey(prevElement);//String equivalent of previous element ==> text(q)
			if(str1 == "--_NOTFOUND@@NOTFOUND_--")//If new element does not exist in hashmap
			{
				ch = str[0];//fc(q)
				output<<str+ch;//Output text(q)fc(q)
				map.insert((map.findKey(prevElement)+ch));//Insert text(q)fc(q) into hashmap
				prevElement = newElement;//New element is now the previous element
			}
			else//If new element does exist in hashmap
			{
				output<<str1;//Output text(x)
				ch = str1[0];//fc(x)
				map.insert((map.findKey(prevElement)+ch));//Insert text(q)fc(x)
				prevElement = newElement;//New element is now the previous element
			}

		}

	}


	//Close both files
	input.close();
	output.close();



	cin.get();
	cin.ignore();
	return 0;
}
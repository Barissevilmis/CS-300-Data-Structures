#ifndef _HASHMAP
#define _HASHMAP


#include <iostream>
#include <string>

using namespace std;

#define SIZE 4096 //Size of HashArray

enum EntryType{EMPTY,ACTIVE};//Our Hashmap indices can be active or empty => No deletion

template<class HashedObj>
class HashMap
{
public:

	explicit HashMap(const HashedObj & notFound);//constructor

	void insert(const HashedObj & obj );//Insert function => Put given strings into array
	const int & findCode(const HashedObj & obj) const; // Find string-code pairs=> return code part

	int hashing(const HashedObj & key) const;//Hash function => hash template(string) object

	const bool & operator==(const HashedObj & rhs) const;//Overloaded equality check operators
	const bool & operator!=(const HashedObj & rhs) const;

private:
	struct HashEntry//Type of hash array
	{
		HashedObj key;//Template(string)=>key 
		int code;//Given integer code pair of key
		EntryType type;//Keep whether given indice is active or not
		
		HashEntry(EntryType t = EMPTY)//Mark as empty when created
			:type(t)
		{}

		HashEntry(HashedObj k,int c, EntryType t = EMPTY)//Create new Hash Object with given string-code pair and mark it
			:key(k),code(c),type(t)
		{}

	};
	HashEntry hashArray[SIZE];//Static array will be used since size is known beforehand
	int currentPos ;//Keep current position as to be code part of next inserted key
	const HashedObj ITEM_NOT_FOUND;//Keep this value since we will return this findKey fails
	

	int findPos(const HashedObj & x) const;//Find given object
	bool isActive(int curr) const;//Check whether given position is active or empty

};

template<class HashedObj>
HashMap<HashedObj>::HashMap(const HashedObj & notFound)	//constructor implementation
	:ITEM_NOT_FOUND(notFound)
{
	for(int i = 0; i < 256; i++)//Enter ASCII Table => 0-255
	{
		HashedObj s;
		s = (char) i;//Take ASCII equivalent of number
		int hashIndex = hashing(s);//Hash given ASCII code
		hashArray[hashIndex]= HashEntry(s,i,ACTIVE);//Insert ASCII key-code pairs as ACTIVE into hashed index
	}
	currentPos = 256;//We will start inserting from 256
}
template <class HashedObj>
bool HashMap<HashedObj>::isActive(int curr) const
{
	return hashArray[curr].type == ACTIVE;//If active return true, otherwise false
}

template<class HashedObj>
int HashMap<HashedObj>::hashing(const HashedObj & key) const//Hash function
{//Horner's method is used for hashing the given string=>It will be sufficient in terms of hashing given strings with minimal collision
	int hashVal = 0;
	string skey = (string) key;

	for (int i = 0; i < skey.length(); i++) 
		hashVal = 37 * hashVal + key[ i ];

	hashVal = hashVal % SIZE;

	if (hashVal < 0) 
		hashVal = hashVal + SIZE;

	return(hashVal);//Return hashed index

}

template<class HashedObj>
void HashMap<HashedObj>::insert(const HashedObj & obj )
{

	int curr = findPos(obj);//Find position of given obj
	if(isActive(curr))//If position active return without inserting => Can only happen if Array is full=>Assuming wont happen
		return;
	hashArray[curr] = HashEntry( obj,currentPos, ACTIVE );//Insert into hashed index
	currentPos++;//Increment Current Position since new string will require a new unique code 
}

template<class HashedObj>
const int & HashMap<HashedObj>::findCode(const HashedObj & obj ) const//Return given string-code pairs code part=>String given, return code
{
	int curr = findPos(obj);//Find position of given string in array
	if (isActive( curr )) //If that position is ACTIVE=> obj exists
		return hashArray[curr].code; //Return code 

	return -1;//Code not found=> obj does not exist
}

template<class HashedObj>
int HashMap<HashedObj>::findPos( const HashedObj & obj ) const//Find position of given object
{
	int curr= hashing(obj);//Hash given object to find its array index

	while( hashArray[curr].type != EMPTY && hashArray[curr].key != obj )//If given index is ACTIVE and another object
	{
		curr++ ;  //Since linear probing go to next index
		if(curr >= SIZE)             //If curr reaches or goes beyond the size 
			curr = curr-SIZE;        //Perform necessary operation
	}

	return curr;//When loop iteration finished=>If obj index found=> return it


}

template<class HashedObj>
const bool & HashMap<HashedObj>::operator==(const HashedObj & rhs) const//Overloaded equality check operator
{
	int curr = hashing(rhs);//Hash right hand side obj
	if(hashArray[curr].key == rhs)//If hashed indexes key is equal to the rhs object
		return true;//Equality confirmed

	return false;//Not Equal
}
template<class HashedObj>
const bool & HashMap<HashedObj>::operator!=(const HashedObj & rhs) const//Exact opposite of equality check operator
{
	int curr = hashing(rhs);
	if(hashArray[curr].key == rhs)
		return false;

	return true;
}

#endif






#include "HashMap.h"
#include <fstream>
#include <sstream>

using namespace std;

int main()
{
	char ch;
	HashMap<string> map("0");//0 wont be used=> Use it as ITEM_NOT_FOUND
	int newElement;

	string fileName = "compin";//Input file
	string fileName2 = "compout";//Output file
	ifstream input;
	ofstream output;

	input.open(fileName.c_str());//Open both files
	output.open(fileName2.c_str());

	string str = "";

	while(!input.eof()) //eof returns true if next character exists
	{
		input.get(ch); //get command reads next character
						//unless you are at the end of the file

		if(map.findCode(str+ch) != -1)//If str+ch already exists in dictionary
		
			str = str+ch;//If str+ch is already encoded in our HashTable => Take next char and concatenate with encoded string
				
		else
		{
			newElement = map.findCode(str);//Already encoded element
			output<< newElement<< " ";
			map.insert(str+ch);//Encode str+ch, since we might need it in future for constant find operations
			str=ch;//Previous str was already encoded=> Get rid of prev str 
				   //str had an upgrade ch, which is newly inserted => Continue with its upgrade character
				   //In other words, directly skip to the last char of newly inserted string
		}

	}

	str = str.substr(1,str.length());
	newElement = map.findCode(str);

	if(newElement != -1)//If exists, output last element
		output<<newElement<<" ";

	//Close both of the files
	input.close();
	output.close();



	cin.get();
	cin.ignore();
	return 0;
}